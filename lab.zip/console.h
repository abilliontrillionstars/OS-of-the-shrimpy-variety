#pragma once

void console_putc(char ch);