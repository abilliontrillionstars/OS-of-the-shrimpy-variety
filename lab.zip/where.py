import sys
import os.path
print(sys.executable)

## C:\Users\ethan\AppData\Local\Programs\Python\Python311\python.exe